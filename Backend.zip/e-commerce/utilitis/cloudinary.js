import {v2 as cloudinary} from 'cloudinary';
          
cloudinary.config({ 
  cloud_name: 'dfymcya5h', 
  api_key: '778726167574396', 
  api_secret: 'KkBhX8xJQFVr9stNwPj2E_Av6kI' 
});
export default cloudinary